package cs.uga.edu.gabgab;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class MainChatActivity extends AppCompatActivity {

    private String mDisplayName;
    private ListView mChatListView;
    private EditText mInputText;
    private ImageButton mSendButton;
    private ImageButton mBackButton;
    private DatabaseReference mDatabaseReference;
    private ChatMsgListAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_chat);

        this.getSupportActionBar().hide();

        // Set up the display name and get the Firebase reference
        setUpDisplayName();
        mDatabaseReference= FirebaseDatabase.getInstance().getReference();


        // Link the Views in the layout to the Java code
        mInputText =findViewById(R.id.messageInput);
        mSendButton =findViewById(R.id.sendButton);
        mChatListView =findViewById(R.id.chat_list_view);
        mBackButton =findViewById(R.id.backButton);

        // Goto HomeScreen when the "back" button is pressed
        mBackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                Intent gotoHomeScreen = new Intent(MainChatActivity.this,HomeScreen.class);
                startActivity(gotoHomeScreen);
            }
        });

        //  Send the message when the "enter" button is pressed
        mInputText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                return true;
            }
        });


        //  Add an OnClickListener to the sendButton to send a message
        mSendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendMessage();
            }
        });

    }

    //Retrieve the name from the Firebase
    private void setUpDisplayName(){

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        mDisplayName = user.getDisplayName();
        if(mDisplayName==null) mDisplayName="Unknown User";

    }


    private void sendMessage() {
        Log.d("ChatApp","Send text");

        //push the message to Firebase
        String input=mInputText.getText().toString();
        if(!input.equals("")){
            Message chat=new Message(input, mDisplayName);
            mDatabaseReference.child("messages").push().setValue(chat);
            mInputText.setText("");
        }

    }

    //Override the onStart() lifecycle method. Setup the adapter
    @Override
    public void onStart() {
        super.onStart();
        mAdapter=new ChatMsgListAdapter(this, mDatabaseReference, mDisplayName);
        mChatListView.setAdapter(mAdapter);
    }


    @Override
    public void onStop() {
        super.onStop();

        //Remove the Firebase event listener on the adapter.
        mAdapter.cleanup();

    }
}