package cs.uga.edu.gabgab;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;

import java.util.ArrayList;

public class ChatMsgListAdapter extends BaseAdapter {

    private Activity mActivity;
    private DatabaseReference mDatabaseReference;
    private String mDisplayName;
    private ArrayList<DataSnapshot> mSnapshotList;

    private ChildEventListener mListener=new ChildEventListener() {
        @Override
        public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
            mSnapshotList.add(dataSnapshot);
            notifyDataSetChanged();

        }

        @Override
        public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

        }

        @Override
        public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

        }

        @Override
        public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

        }

        @Override
        public void onCancelled(@NonNull DatabaseError databaseError) {

        }
    };

    public ChatMsgListAdapter(Activity activity, DatabaseReference ref, String name){
        mActivity=activity;
        mDisplayName=name;
        mDatabaseReference=ref.child("messages");
        mDatabaseReference.addChildEventListener(mListener);
        mSnapshotList=new ArrayList<>();
    }

    static class ViewHolder{
        TextView senderName;
        TextView dateTime;
        TextView body;
        LinearLayout.LayoutParams params;

    }


    @Override
    public int getCount() {
        return mSnapshotList.size();
    }

    @Override
    public Message getItem(int position) {
        DataSnapshot snapshot=mSnapshotList.get(position);

        //Convert JSON from snapshot into the message object
        return snapshot.getValue(Message.class);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView==null){
            LayoutInflater inflater= (LayoutInflater) mActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView=inflater.inflate(R.layout.chat_msg_row,parent,false);
            final ViewHolder holder=new ViewHolder();
            holder.senderName=convertView.findViewById(R.id.sender);
            holder.body=convertView.findViewById(R.id.message);
            holder.params=(LinearLayout.LayoutParams) holder.senderName.getLayoutParams();
            convertView.setTag(holder);
        }

        final Message message = getItem(position);
        final ViewHolder holder=(ViewHolder) convertView.getTag();

        boolean thisUser=message.getSender().equals(mDisplayName);
        setChatRowAppearance(thisUser,holder);

        String sender=message.getSender();
        holder.senderName.setText(sender);

        String msg=message.getMessage();
        holder.body.setText(msg);


        return convertView;
    }

    private void setChatRowAppearance(boolean thisSideUser, ViewHolder holder){
        if(thisSideUser){
            holder.params.gravity= Gravity.RIGHT; //Gravity.getAbsoluteGravity(1,1);//
            holder.senderName.setTextColor(Color.rgb(255,152,0));
            holder.body.setBackgroundResource(R.drawable.speech2);

        }
        else {
            holder.params.gravity=Gravity.LEFT;
            holder.senderName.setTextColor(Color.rgb(40,117,154));
            holder.body.setBackgroundResource(R.drawable.speech1);

        }

        holder.senderName.setLayoutParams(holder.params);
        holder.body.setLayoutParams(holder.params);

    }

    public void cleanup(){
        mDatabaseReference.removeEventListener(mListener);
    }
}
