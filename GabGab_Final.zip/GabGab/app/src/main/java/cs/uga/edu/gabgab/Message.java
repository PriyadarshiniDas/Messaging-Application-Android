package cs.uga.edu.gabgab;

import java.sql.Date;
import java.sql.Time;

public class Message {
    private String message;
    private String sender;

    public Message(String message, String sender) {
        this.message = message;
        this.sender = sender;
    }

    public Message() {

    }

    public String getMessage() {
        return message;
    }

    public String getSender() {

        if(sender==null) sender="Name not saved";
        return sender;
    }
}
